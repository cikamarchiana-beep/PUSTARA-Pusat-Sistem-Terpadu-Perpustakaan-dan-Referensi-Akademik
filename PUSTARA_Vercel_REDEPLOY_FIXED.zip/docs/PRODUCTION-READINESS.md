# PUSTARA — Batasan dan Pekerjaan Sebelum Go-Live Publik

Aplikasi ini **sudah dapat di-host di Vercel sebagai static frontend**, dengan visual, ilustrasi, animasi, dan data simulasi tetap tersedia. Namun menerbitkan URL bukan berarti sistem informasi perpustakaan sudah siap transaksi nyata.

## Pekerjaan wajib sebelum dipakai mahasiswa/petugas sungguhan

1. **Backend bersama**: pindahkan transaksi peminjaman, pengembalian, booking, kompensasi, histori dan audit dari browser ke API server. Gunakan database bersama dengan migrasi, backup, kontrol akses dan retensi.
2. **Autentikasi resmi**: hapus password demo, gunakan SSO/OIDC atau auth server yang disetujui kampus; implementasikan session cookie aman, MFA untuk admin, reset password server-side dan rate limiting.
3. **Kontrol peran di server**: hak mahasiswa/petugas/supervisor/admin harus diverifikasi oleh API. Menu yang disembunyikan di frontend tidak cukup untuk otorisasi.
4. **Pembayaran riil**: kontrak payment gateway QRIS; gunakan VA/rekening sah, bukan nomor contoh. Untuk transfer manual, wajib ada bukti dan rekonsiliasi; untuk cash, sertakan pelacakan kasir. Verifikasi oleh petugas harus disertai identitas, timestamp, jejak audit, dan anti-duplikasi transaksi.
5. **Notifikasi lintas akun**: mekanisme push/email/in-app yang tersimpan di backend. Jangan mengandalkan localStorage pengguna untuk mengirim notifikasi ke petugas.
6. **Keamanan & privasi**: enkripsi data pribadi, kebijakan akses/retensi, logging yang tidak membocorkan password, CSRF/XSS review, audit trail immutable untuk transaksi kritis, pemulihan insiden.
7. **Penetapan kebijakan perpustakaan**: pastikan tarif keterlambatan, denda, jam operasional, nomor rekening dan aturan pengembalian disahkan pengelola perpustakaan. Jangan memakai tarif simulasi sebagai tarif resmi.
8. **Uji produksi**: pengujian terintegrasi multi-browser/multi-pengguna, aksesibilitas, backup/restore, beban, review keamanan dan UAT oleh pihak kampus.

## Tidak ada backend dalam ZIP ini

`vercel.json` hanya mengatur hosting static/HTTP header. Tidak ada API atau database dan tidak ada integrasi gateway sungguhan; jangan menganggap verifikasi pembayaran di satu browser terlihat di browser petugas lain. Jika frontend sudah publik, beri pembatasan pengguna sampai pekerjaan di atas selesai.
