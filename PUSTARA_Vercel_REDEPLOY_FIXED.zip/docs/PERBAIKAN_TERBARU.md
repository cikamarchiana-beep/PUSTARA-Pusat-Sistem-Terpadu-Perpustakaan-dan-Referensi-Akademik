# PUSTARA — Perbaikan Layout & Kontras Terbaru (8 Oktober 2026)

Ini adalah pembaruan dari ZIP PUSTARA sebelumnya, BUKAN rancangan ulang.

## Perbaikan

- PUSTARA dark theme: layar Pilih Role, label Login, tombol Launcher, speech bubble, layanan pastel, feature teaser, katalog, kartu laporan, leaderboard, tabel, feedback, dan teks kecil.
- Katalog: reset properti `top: 88px` pada toolbar yang bukan lagi sticky. Filter, ringkasan hasil, dan kartu buku tidak lagi bertumpuk.
- Grid filter katalog reflow otomatis pada desktop/tablet/mobile; kartu rekomendasi dibagi dua kolom di ponsel.
- Mobile: sidebar sekarang `position: fixed` saat layar kecil. Ini mencegah sidebar tersembunyi mengambil ruang vertikal 837 px, yang sebelumnya membuat aplikasi terlihat kosong.
- Data koleksi: label jumlah judul disesuaikan dengan dataset 450 judul.
- Seluruh ilustrasi dan animasi utama, receipt animasi, pembayaran, verifikasi petugas, serta hak akses setiap peran tetap dipertahankan.

## Hasil validasi

- Browser Chromium: navigasi seluruh menu di role Anggota, Petugas, Supervisor, dan Admin, masing-masing dalam mode terang dan gelap — tanpa error JavaScript.
- Tampilan katalog: filter di atas informasi hasil, kartu di bawah informasi hasil.
- Lebar 390px, 820px, dan 1440px: urutan katalog benar; di mobile 390px tidak ada overflow dokumen.
- Static asset & logo utama inline/embed, sehingga gambar PUSTARA tidak perlu sumber CDN.

Pengujian URL Vercel sesungguhnya memerlukan deploy ke akun Vercel Anda. Hosting frontend tidak menyinkronkan transaksi antar pengguna: untuk transaksi institusional sungguhan tetap dibutuhkan backend, database, autentikasi dan gateway resmi.
