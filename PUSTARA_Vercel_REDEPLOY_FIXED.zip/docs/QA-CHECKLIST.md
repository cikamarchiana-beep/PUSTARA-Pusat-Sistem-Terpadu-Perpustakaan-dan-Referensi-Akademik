# PUSTARA — QA Checklist Setelah Deploy

## Tampilan (desktop dan mobile)

- [ ] Semua layar terbuka tanpa kehilangan logo atau maskot.
- [ ] Tema Light dan Dark dapat ditukar tanpa reload dan tidak ada teks yang menyatu dengan background.
- [ ] Dashboard: judul hero, quick actions, 4 kartu KPI, grafik, dan peringatan keterlambatan terbaca.
- [ ] Leaderboard: tabel nama/jumlah/category terbaca di kedua tema.
- [ ] Ruangan: form, label, input, serta tabel jadwal terbaca.
- [ ] Feedback: rating, label, form, serta riwayat terbaca.
- [ ] Achievement: semua 20 nama dan ikon yang sudah tersedia tampil.
- [ ] Sidebar tidak menimpa isi konten; layar sempit memakai navigasi responsif.
- [ ] Launcher dan carousel arc serta animasi masuk role/login tetap berjalan.

## Navigasi dan data

- [ ] Pilih Role → Login → Dashboard sesuai role.
- [ ] Menu Katalog, Peminjaman, Pengembalian, Ruangan, Kompensasi, Leaderboard, Feedback, Profil dapat dibuka.
- [ ] Grafik mahasiswa: mode Harian/Mingguan dan tooltip berfungsi.
- [ ] Pembayaran: pilih QRIS/Transfer/Cash; QR/kartu bank demo tampil.
- [ ] Setelah pengajuan: status PENDING dan struk animasi **bukti pengajuan** tampil.
- [ ] Petugas: nomor referensi dan nominal yang cocok diverifikasi; nominal berbeda ditolak.
- [ ] Sesudah disetujui: 2 receipt + 1 bukti bayar tersedia untuk print.
- [ ] Pengembalian buku diperiksa terpisah dari status pembayaran.
- [ ] Cetak struk dari browser tidak ikut mencetak sidebar/dasbor.

## Pengujian browser sebelum publik

- [ ] Chrome / Edge desktop.
- [ ] Safari iOS, Chrome Android.
- [ ] Periksa console Browser DevTools: 0 JavaScript error.
- [ ] Periksa jaringan: seluruh asset yang diminta berstatus 200.

### Batas pengujian otomatis saat pembuatan ZIP

Lulus pada browser headless: navigasi mahasiswa; Dark → Light; halaman Dashboard, Leaderboard, Ruangan, Feedback; pengajuan Transfer Bank; struk animasi; antrean verifikasi petugas; dan cetak 3 lembar. Ini bukan pengganti tes keamanan, pembayaran sungguhan, atau tes banyak pengguna.
